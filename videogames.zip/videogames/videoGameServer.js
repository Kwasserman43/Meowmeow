const express = require('express');
const dotenv = require('dotenv');
const bodyParser = require('body-parser');
const path = require('path');
const readline = require('readline');
const app = express();
dotenv.config({ path: path.resolve(__dirname, ".env") });
const databaseAndCollection = {
  db: process.env.MONGO_DB_NAME,
  collection: process.env.MONGO_COLLECTION,
};

app.set("views", require("path").resolve(__dirname, "view"));
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));


const PORT = process.argv[2];

const { MongoClient, ServerApiVersion } = require('mongodb');
const MONGO_CONNECTION_STRING = "mongodb+srv://kyleevanwasserman:JfBGnRMvJRziitO8@cluster0.bdd2p.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
const uri = process.env.MONGO_CONNECTION_STRING || MONGO_CONNECTION_STRING;
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});
async function run() {
  try {
    await client.connect();
    await client.db("admin").command({ ping: 1 });
    console.log("Pinged your deployment. You successfully connected to MongoDB!");
  } finally {
    await client.close();
  }
}
run().catch(console.dir);


app.set('view engine', 'ejs'); 
app.set('views', './views'); 

dotenv.config();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.render('index');
});

app.get('/submit', (req, res) => {
  res.render('submit');
});




app.post('/submit', async (req, res) => {
  const { name, rating, genre, comments } = req.body;

  if (!name || !rating || !genre || !comments) {
    console.error('Error: Missing required fields');
    return res.status(400).send('Error: All fields are required.');
  }

  const game = {
    name,
    rating,
    genre,
    comments
  };

  const client = new MongoClient(uri, {
    serverApi: ServerApiVersion.v1,
  });

  try {
    await client.connect();
    await client
      .db(databaseAndCollection.db)
      .collection(databaseAndCollection.collection)
      .insertOne(game);
    
      res.render('processGame', {
        name,
        rating,
        genre,
        comments
      });
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).send('Error submitting application.');
  }
});


app.get('/review', (req, res) => {
  res.render('review', { error: null, game: null}); 
});


app.post('/review', async (req, res) => {
  const game = req.body.game; 

  const client = new MongoClient(uri, {
    serverApi: ServerApiVersion.v1,
  });

  try {
    await client.connect();
    const foundGame = await client
      .db(databaseAndCollection.db)
      .collection(databaseAndCollection.collection)
      .findOne({game});

    if (!foundGame) {
      res.render('review', { error: "No game found with this name.", foundGame: null });
    } else {
      res.render('processRequest', {foundGame});
    }
  } catch (err) {
    res.status(500).send("Error retrieving game."); 
  }
});




app.get('/select-by-rating', (req, res) => {
  res.render('selectByRating', { games: null });
});

app.post('/select-by-rating', async (req, res) => {
  const minRating = parseFloat(req.body.rating); 

  const client = new MongoClient(uri, {
    serverApi: ServerApiVersion.v1,
  });

  try {
    await client.connect();

    const cursor = client
      .db(databaseAndCollection.db)
      .collection(databaseAndCollection.collection)
      .find({ minimumRating: { $gte: minRating } });

    const ratingGames = await cursor.toArray(); 

    res.render('processMinimumRating', { rating: minRating, ratingGames }); 
  } catch (err) {
    console.error("Error retrieving games:", err); 
    res.status(500).send("Error retrieving games."); 
  } finally {
    await client.close(); 
  }
});


app.get('/remove-all', (req, res) => {
  res.render('removeAll');
});

app.post('/remove-all', async (req, res) => {
  const client = new MongoClient(uri, {
    serverApi: ServerApiVersion.v1,
  });

  try {
    await client.connect(); 
    const result = await client
      .db(databaseAndCollection.db)
      .collection(databaseAndCollection.collection)
      .deleteMany({}); 

    console.log(`Deleted ${result.deletedCount} documents`);
    res.render('applicationsRemoved', { deletedCount: result.deletedCount });
  } catch (e) {
    console.error("Error removing all applications:", e);
    res.status(500).send("Failed to remove all applications.");
  } finally {
    await client.close(); 
  }
});


app.delete('/remove-all', (req, res) => {
  db.collection(process.env.MONGO_COLLECTION)
    .deleteMany({})
    .then(result => {
      const count = result.deletedCount;
      res.render('applicationsRemoved', { count });
    })
    .catch(err => res.status(500).send('Error removing applications.'));
});


app.post('/process-application', (req, res) => {
  const { name, email, gpa, background } = req.body;

  const date = new Date();
  const options = {
    weekday: 'short',
    year: 'numeric',
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZoneName: 'short'
  };
  const formattedDate = date.toLocaleString('en-US', options);

  res.render('processApplication', {
    name,
    email,
    gpa,
    background,
    date: formattedDate
  });
});

app.listen(PORT, () => {
  console.log(`Web server started and running at http://localhost:${PORT}`);
});